// Mock database
let users = [];

// Show registration form
function showRegisterForm() {
    document.getElementById('loginForm').style.display = 'none';
    document.getElementById('registerForm').style.display = 'block';
}

// Show login form
function showLoginForm() {
    document.getElementById('registerForm').style.display = 'none';
    document.getElementById('loginForm').style.display = 'block';
}

// Register function
function register() {
    const username = document.getElementById('registerUsername').value;
    const password = document.getElementById('registerPassword').value;

    if (username && password) {
        users.push({ username, password });
        alert('Registration successful');
        showLoginForm();
    } else {
        alert('Please enter a username and password');
    }
}

// Login function
function login() {
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;

    const user = users.find(user => user.username === username && user.password === password);

    if (user) {
        document.getElementById('loginForm').style.display = 'none';
        document.getElementById('dashboard').style.display = 'block';
        document.getElementById('user').innerText = username;
    } else {
        alert('Invalid username or password');
    }
}

document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const text = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;

    console.log('Login attempt:', { text, password });
    alert('Login successful');
    if (username === validUsername && password === validPassword) {
        // Redirect to the dashboard page
        window.location.href = 'dashboard.html';
    } 
});



// Reset Password

document.getElementById('forgot-password').addEventListener('click', function() {
    $('#forgotPasswordModal').modal('show');
});

document.getElementById('confirmResetPassword').addEventListener('click', function() {
    $('#forgotPasswordModal').modal('hide');
    $('#emailModal').modal('show');
});

document.getElementById('sendOTP').addEventListener('click', function() {
    const email = document.getElementById('reset-email').value;

    if (!email) {
        alert('Please enter your email');
        return;
    }

    console.log('OTP sent to:', email);
    $('#emailModal').modal('hide');
    alert('OTP sent');
    $('#otpModal').modal('show');
});

document.getElementById('verifyOTP').addEventListener('click', function() {
    const otp = document.getElementById('otp').value;

    if (!otp) {
        alert('Please enter the OTP');
        return;
    }

    console.log('OTP verified:', otp);
    $('#otpModal').modal('hide');
    $('#resetPasswordModal').modal('show');
});

document.getElementById('resetPasswordButton').addEventListener('click', function() {
    const newPassword = document.getElementById('new-password').value;
    const confirmNewPassword = document.getElementById('confirm-new-password').value;

    if (newPassword !== confirmNewPassword) {
        alert('Passwords do not match');
        return;
    }

    console.log('Password reset successfully:', newPassword);
    $('#resetPasswordModal').modal('hide');
    alert('Password reset successfully');
});


