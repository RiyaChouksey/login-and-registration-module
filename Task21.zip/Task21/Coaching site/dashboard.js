// enquery form

function toggleForm() {
    const formContainer = document.getElementById("inquiryFormContainer");
    if (formContainer.style.display === "none" || formContainer.style.display === "") {
        formContainer.style.display = "block";
    } else {
        formContainer.style.display = "none";
    }
}

function validateForm() {
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const subject = document.getElementById("subject").value;
    const message = document.getElementById("message").value;
    const formMessage = document.getElementById("formMessage");

    // Simple validation checks
    if (name === "" || email === "" || subject === "" || message === "") {
        formMessage.textContent = "All fields are required.";
        formMessage.style.color = "red";
        return false;
    }

    // Further validation for email can be added here

    formMessage.textContent = "Inquiry submitted successfully!";
    formMessage.style.color = "green";
    return true;
}

document.getElementById('back-to-top').addEventListener('click', function() {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});

function enroll() {
    alert("You have enrolled in the course!");
}
